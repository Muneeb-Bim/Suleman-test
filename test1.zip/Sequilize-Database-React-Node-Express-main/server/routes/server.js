const express = require("express");
const router = express.Router();
const db = require("../db");
const Restaurants = require("../modules/restaurants");
const Reviews = require("../modules/reviews");
const Users = require("../modules/users");
const bcrypt = require("bcrypt");
const jwtGenerator = require("../utils/jwtGenerator");
const validinfo = require("../middleware/validinfo");
const authorization = require("../middleware/authorization");
// const {sequelize} = require("sequelize");

//Registering
router.post("/register", validinfo, async (req, res) => {
  try {
    // 1. destructing the req.body (name,email.password)
    const { name, email, password } = req.body;
    //2. check if user exist(if user exist then throw error)
    const user = await Users.findOne({ where: { user_email: email } });
    // res.json(user.rows)
    if (user) {
      return res.status(401).json("User already exist");
    }
    //3. Bcrypt the user password
    const saltRound = 10;
    const salt = await bcrypt.genSalt(saltRound);
    const bcryptPassword = await bcrypt.hashSync(password, salt);
    //4. enter the new user inside the database
    const newUser = await Users.create({
      user_name: name,
      user_email: email,
      user_password: bcryptPassword,
    });
    const jwtToken = jwtGenerator(newUser.user_id);
    return res.json({ jwtToken });
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Server Error");
  }
});
// login route
router.post("/login", validinfo, async (req, res) => {
  // 1. destructing the req.body
  const { email, password } = req.body;
  try {
    //2. check if user dosn't exist(if not then throw error)
    const user = await Users.findOne({
      where: { user_email: email },
    });
    if (!user) {
      return res.status(401).json("Invalid email ");
    }
    // 3. chk if incoming  password is same the database password
    const validPassword = await bcrypt.compareSync(
      password,
      user.user_password
    );
    if (!validPassword) {
      return res.status(401).json("Invalid email or password");
    }
    //4. give the jwt token
    const jwtToken = jwtGenerator(user.user_id);
    return res.json({ jwtToken });
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Server Error");
  }
});
router.post("/is-verify", authorization, async (req, res) => {
  try {
    res.json(true);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});
// Home
router.get("/home", authorization, async (req, res) => {
  try {
    const user = await Users.findOne({
      attributes: ["user_name"],
      where: {
        user_id: req.user,
      },
    });
    res.json(user);
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Server Error");
  }
});
// Get all Restaurants
router.get("/", async (req, res) => {
  try {
    // const restaurantRatingsData = await Restaurants.findAll();
    const restaurantRatingsData = await Restaurants.findAll({
      attributes: [
        "id",
        "name",
        "location",
        "price_range",
        "reviews.restaurant_id",
        [db.fn("COUNT", db.col("reviews.restaurant_id")), "count"],
        [db.fn("TRUNC", db.fn("AVG", db.col("rating")), 1), "average_rating"],
      ],
      include: [
        {
          model: Reviews,
          attributes: [],
        },
      ],
      group: ["restaurants.id", "reviews.restaurant_id"],
      order:[['count','DESC']],
      raw: true,
    });
    res.status(200).json({
      status: "success",
      results: restaurantRatingsData.length,
      data: {
        restaurants: restaurantRatingsData,
      },
    });
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});
// Get One Restaurant
router.get("/:id", async (req, res) => {
  try {
    // const { id } = req.body;
    const restaurant = await Restaurants.findOne({
      attributes: [
        "id",
        "name",
        "location",
        "price_range",
        "reviews.restaurant_id",
        [db.fn("COUNT", db.col("reviews.restaurant_id")), "count"],
        [db.fn("TRUNC", db.fn("AVG", db.col("rating")), 1), "average_rating"],
      ],
      include: [
        {
          model: Reviews,
          attributes: [],
        },
      ],
      where: {
        id: req.params.id,
      },
      group: ["restaurants.id", "reviews.restaurant_id"],
      order:[['count','DESC']],
      raw: true,
    });
    const reviews = await Reviews.findAll({
      where: { restaurant_id: req.params.id },
    });
    res.status(200).json({
      status: "success",
      data: {
        restaurants: restaurant,
        reviews: reviews,
      },
    });
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Create a Restaurant
router.post("/", async (req, res) => {
  try {
    const { name, location, price_range } = req.body;

    const results = await Restaurants.create({
      name,
      location,
      price_range,
    });
    res.status(201).json({
      status: "success",
      data: {
        restaurants: results,
      },
    });
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});
// Update a Restaurant
router.put("/:id", async (req, res) => {
  try {
    const { id, name, location, price_range } = req.body;

    const results = await Restaurants.update(
      {
        name,
        location,
        price_range,
      },
      { where: { id: req.params.id } }
    );
    res.status(201).json(results);
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});
// Delete a Restaurant
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.body;

    const results = await Restaurants.destroy({ where: { id: req.params.id } });
    res.status(201).json(results);
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});
// Add Reviews
router.post("/:id/addReview", async (req, res) => {
  try {
    const { uname, review, rating } = req.body;

    const newReview = await Reviews.create({
      restaurant_id: req.params.id,
      uname,
      review,
      rating,
    });
    res.status(201).json({
      status: "success",
      data: {
        review: newReview,
      },
    });
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
