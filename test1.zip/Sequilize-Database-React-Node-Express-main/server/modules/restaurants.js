const {DataTypes} = require("sequelize");
const db = require("../db");

const Restaurants = db.define("restaurants",{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
    name:{
        type: DataTypes.STRING,
        allowNull: false
    },
    location:{
        type: DataTypes.STRING,
        allowNull: false  
    },
    price_range:{
        type: DataTypes.STRING,
        allowNull: false  
    }    
    
},
{
    freezeTableName: true,
    createdAt: false,
    updatedAt: false
    // timestamps: false

})

db.sync();

module.exports = Restaurants;