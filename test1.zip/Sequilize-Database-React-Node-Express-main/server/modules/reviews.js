const { DataTypes } = require("sequelize");

const db = require("../db");
const Restaurants = require("./restaurants");

const Reviews = db.define(
  "reviews",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    uname: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    review: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    rating: {
      type: DataTypes.BIGINT,
      allowNull: false,
      rating: {
        [DataTypes.and]: {
          [DataTypes.lt]: 6,
          [DataTypes.gt]: 0,
        },
      },
    },
  },
  {
    freezeTableName: true,
    createdAt: false,
    updatedAt: false,
    // timestamps: false
  }
);

Restaurants.hasMany(Reviews, { foreignKey: 'restaurant_id', onDelete:"CASCADE" });
Reviews.belongsTo(Restaurants, { foreignKey: 'restaurant_id' });
db.sync();

module.exports = Reviews;
