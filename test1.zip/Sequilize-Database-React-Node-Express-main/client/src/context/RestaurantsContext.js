import React, { useState, createContext, useEffect, useContext } from "react";

export const RestaurantsContext = createContext();
export const RContext  = () => useContext(RestaurantsContext);

export const RestaurantsContextProvider = (props) => {
  const [restaurants, setRestaurants] = useState([]);
  const [selectedRestaurant, setSelectedRestaurant] = useState(null);
  const addRestaurants = (restaurant) => {
    setRestaurants([...restaurants, restaurant]);
    
  };
  const [isAuthenticated, setIsAuthendicated] = useState(false);
  const setAuth = (boolean) => {
    setIsAuthendicated(boolean);
  };

  const isAuth = async () => {
    try {
      const response = await fetch("http://localhost:3008/auth/is-verify/",
      {
        method: "POST",
        headers: { jwtToken: localStorage.jwtToken }
      });
      const parseRes = await response.json();
      parseRes === true ? setIsAuthendicated(true):setIsAuthendicated(false);
    } catch (err) {
      // console.error(err.message);
    }
  };

  useEffect(() => {
    isAuth();
  }, []);
  return (
    <RestaurantsContext.Provider
      value={{
        restaurants,
        setRestaurants,
        addRestaurants,
        selectedRestaurant,
        setSelectedRestaurant,
        setAuth,
        isAuthenticated,
        setIsAuthendicated,
      }}
    >
      {props.children}
    </RestaurantsContext.Provider>
  );
};
// export const useRestaurantsContext = () => useContext(RestaurantsContext)
