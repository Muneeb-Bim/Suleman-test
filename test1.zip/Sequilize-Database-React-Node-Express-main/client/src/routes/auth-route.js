import React from "react";


import {Navigate} from "react-router-dom";
import { RContext } from "../context/RestaurantsContext";


const AuthRoute = ({ children}) => {
const rcontext = RContext();
    if (rcontext.isAuthenticated) {
        return <Navigate to={"/"} />;
      }
    
      return children;
  }

export default AuthRoute;
