import React from "react";
import { Navigate } from "react-router-dom";
import { RContext } from "../context/RestaurantsContext";

const PrivateRoute = ({children}) => {
const rcontext = RContext();
    if (!rcontext.isAuthenticated) {
        return <Navigate to={"/login"} />;
      }
    
      return children;
  }



export default PrivateRoute;
