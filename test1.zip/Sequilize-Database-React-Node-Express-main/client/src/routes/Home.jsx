import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import AddRestaurant from "../components/AddRestaurant";
import RestaurantList from "../components/RestaurantList";
import { toast } from "react-toastify";
import { RContext } from "../context/RestaurantsContext";
import {Web3} from "web3"

const Home = ({ setAuth }) => {
  const [name, setName] = useState("");
    const [ walletAddress, setWalletAddress] = useState("");
  const rcontext = RContext();
  const getProfile = async () => {
    try {
      const response = await fetch("http://localhost:3008/app/home/", {
        method: "GET",
        headers: { jwtToken: localStorage.jwtToken },
      });

      const parseRes = await response.json();
      //   console.log(parseRes)
      setName(parseRes.user_name);
      
    } catch (err) {
      console.error(err.message);
    }
  };
  const handleWallet =async(e)=>{
    e.preventDefault();

    if(window.ethereum){
      // console.log("Detected")
      try{
        const accounts = await window.ethereum.request({
          method:"eth_requestAccounts",
        })
        setWalletAddress(accounts[0])
        // accounts=walletAddress? walletAddress:"Connect Wallet";
      }catch
      {
        console.log("Error.........")
      }
    }
    else{
      console.log("err")
    }
  }
  const getTruncatedAddress = () => {
    if(walletAddress!==""){
      return `${walletAddress?.slice(0,6)}******${walletAddress?.slice(-4)}`;
    }
  } 
 
  const logout = async (e) => {
    e.preventDefault();
    try {
      localStorage.removeItem("jwtToken");
      rcontext.setAuth(false);
      // window.location.href = '/login';
      toast.success("Logout successfully");
    } catch (err) {
      console.error(err.message);
    }
  };

  useEffect(() => {
    getProfile();
    
  }, []);
  return (
    <div>
      <div className="container">
        <div className="row">
          <div className="col-md-9">
            <h1>Welcome {name}</h1>
            {/* <h5>Wallet Address:  {walletAddress}</h5> */}
          </div>
          <div className="col-md-3">
            <button onClick={(e) => logout(e)} className="btn btn-primary">
              Logout
            </button>
            <button onClick={(e)=> handleWallet(e)} className="btn btn-success ml-3">
              <span>{getTruncatedAddress()?getTruncatedAddress(): "Connect Wallet" }</span>
            </button>
          </div>
        </div>
      </div>
      <Header />
      <AddRestaurant />
      <RestaurantList />
    </div>
  );
};

export default Home;
