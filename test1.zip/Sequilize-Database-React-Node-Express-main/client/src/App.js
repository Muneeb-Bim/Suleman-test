import React, { useEffect, useState } from "react";
import { Routes, Route, BrowserRouter } from "react-router-dom";
import Home from "./routes/Home";
import RestaurantsDetail from "./routes/RestaurantsDetail";
import Update from "./routes/Update";
import { RestaurantsContextProvider } from "./context/RestaurantsContext";
import Login from "./components/Login";
import Register from "./components/Register";
import AuthRoute from "./routes/auth-route";
import PrivateRoute from "./routes/private-route";

import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const App = () => {

  return (
    <RestaurantsContextProvider>
      <div className="container">
        <BrowserRouter>
          <ToastContainer position="top-center" />
          <Routes>
            <Route
              exact
              path="/"
              element={
                <PrivateRoute>
                  <Home />
                </PrivateRoute>
              }
            />
            <Route
              exact
              path="/restaurants/:id"
              element={
                <PrivateRoute>
                  <RestaurantsDetail />
                </PrivateRoute>
              }
            />
            <Route
              exact
              path="/restaurants/:id/update"
              element={
                <PrivateRoute>
                  <Update />
                </PrivateRoute>
              }
            />
            <Route
              exact
              path="/login"
              element={
                <AuthRoute>
                  <Login />
                </AuthRoute>
              }
            />
            <Route
              exact
              path="/register"
              element={
                <AuthRoute>
                  <Register />
                </AuthRoute>
              }
            />
          </Routes>
        </BrowserRouter>
      </div>
    </RestaurantsContextProvider>
  );
};

export default App;
