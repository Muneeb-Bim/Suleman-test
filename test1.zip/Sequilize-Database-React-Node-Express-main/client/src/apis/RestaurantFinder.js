import axios from 'axios';

export default axios.create({
    baseURL:'http://localhost:3008/api/v1/restaurants',
});