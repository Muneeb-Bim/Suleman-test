import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { RContext } from "../context/RestaurantsContext";
// import "react-toastify/dist/ReactToastify.css";

const Login = ({ setAuth }) => {
  const [inputs, setInputs] = useState({
    email: "",
    password: "",
  });

  const { email, password } = inputs;
  const navigate= useNavigate();
  const rcontext = RContext();

  const onChange = (e) =>
    setInputs({ ...inputs, [e.target.name]: e.target.value });

  const onSubmitForm = async (e) => {
    e.preventDefault();
    try {
      const body = { email, password };
      const response = await fetch("http://localhost:3008/auth/login/", {
        method: "POST",
        headers: {
          "Content-type": "application/json",
        },
        body: JSON.stringify(body),
      });

      const parseRes = await response.json();
      // console.log(parseRes);

      if (parseRes.jwtToken) {
        localStorage.setItem("jwtToken", parseRes.jwtToken);
        rcontext.setAuth(true);
        // window.location.href='/';
        toast.success("Logged in Successfully");
      } else {
        rcontext.setAuth(false);
        toast.error(parseRes);
      }
    } catch (err) {
        // console.error(err.message);
    }
  };
  // useEffect(()=>{
  //   if(rcontext.isAuthenticated){
  //     navigate('/');
  //   }
  // },[rcontext,navigate])
  return (
    <div className="container">
      <h1 className="mt-5 text-center">Login</h1>
      <form onSubmit={onSubmitForm}>
        <input
          type="text"
          required
          name="email"
          autoComplete="on"
          placeholder="test@gmail.com"
          value={email}
          onChange={(e) => onChange(e)}
          className="form-control my-3"
        />
        <input
          type="password"
          name="password"
          required
          autoComplete="on"
          placeholder="Enter Your Password"
          value={password}
          onChange={(e) => onChange(e)}
          className="form-control my-3"
        />
        <button type="submit" className="btn btn-success btn-block">
          Submit
        </button>
      </form>
      <Link to="/register">I don't have Account</Link>
    </div>
  );
};

export default Login;
