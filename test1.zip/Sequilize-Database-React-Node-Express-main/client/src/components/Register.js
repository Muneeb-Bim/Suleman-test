import React, { useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import { RContext } from "../context/RestaurantsContext";


const Register = ({ setAuth }) => {
  const [inputs, setInputs] = useState({
    name: "",
    email: "",
    password: "",
  });
  const { name, email, password } = inputs;
  const rcontext = RContext();
  // const navigate= useNavigate();

  const onChange = (e) => {
    setInputs({ ...inputs, [e.target.name]: e.target.value });
  };
  const onSubmitForm = async (e) => {
    e.preventDefault();
    try {
      const body = { name, email, password };
      const response = await fetch("http://localhost:3008/auth/register/", {
        method: "POST",
        headers: {
          "Content-type": "application/json",
        },
        body: JSON.stringify(body),
      });
      const parseRes = await response.json();
      if (parseRes.jwtToken) {
        localStorage.setItem("jwtToken", parseRes.jwtToken);
        rcontext.setAuth(true);
        // window.location.href='/';
        // navigate("/")
        toast.success("Registered Successfully");
      } else {
        rcontext.setAuth(false);
        toast.error(parseRes);
      }
    } catch (err) {
    //   console.error(err.message);
    }
  };
  return (
    <div className="container">
      <h1 className="text-center my-5">Register</h1>
      <form action="" onSubmit={onSubmitForm}>
        <input
          type="text"
          name="name"
          placeholder="enter your username"
          autoComplete="on"
          required
          className="form-control my-3"
          value={name}
          onChange={(e) => {
            onChange(e);
          }}
        />
        <input
          type="email"
          name="email"
          placeholder="test@gmail.com"
          autoComplete="on"
          required
          className="form-control my-3"
          value={email}
          onChange={(e) => {
            onChange(e);
          }}
        />
        <input
          type="password"
          name="password"
          placeholder="enter a password"
          autoComplete="on"
          required
          className="form-control my-3"
          value={password}
          onChange={(e) => {
            onChange(e);
          }}
        />
        <button type="submit" className="btn btn-success btn-block">
          Submit
        </button>
      </form>
      <Link to="/login">I have already an Account</Link>
    </div>
  );
};

export default Register;
